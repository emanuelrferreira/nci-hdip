//fix the code by figuring out what should be in the **** sections
public class EggBox{
	//vars
	**** int eggs;
	**** **** boxSize;
	**** **** numBoxes;
	**** **** leftOverEggs;
	//set
	public **** setEggs(int eggs){
		this.eggs=eggs;
	}
	public **** setBoxSize(int ****){
		this.****=****;
	}
	//compute
	public void computeBoxes(){
		numBoxes=eggs/6;
	}
	public void computeLeftover(){
		leftOverEggs=****;
	}
	//get
	public **** getBoxes(){
		return boxes;
	}
	public **** getLeftover(){
		return leftover;
	}
}