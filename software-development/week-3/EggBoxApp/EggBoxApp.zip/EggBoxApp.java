//fix the code by figuring out what should be in the **** sections
import javax.****.JOptionPane;
public class EggBox****{
	public static void main(String[] args){
		//variables
		int eggs;
		int boxSize;
		int numBoxes;
		int leftOverEggs;
		//objects
		**** egg;
		****=new EggBox();
		//inputs
		*****=Integer.****(JOptionPane.****(null,"Enter a number of eggs"));
		boxSize=6;
		//set
		egg.setEggs(****);
		egg.setBoxSize(****);
		//compute
		****.computeBoxes();
		****.computeLeftover();
		//get
		****=egg.getBoxes();
		****=egg.getLeftover();
		//output
		JOptionPane.****(null,"Number of boxes needed "+numBoxes);
		JOptionPane.****(null,"Number of eggs left over "+leftOverEggs);
	}
}