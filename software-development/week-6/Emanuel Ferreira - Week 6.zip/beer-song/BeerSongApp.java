/*
BeerSongAPP.java
Emanuel Ferreira
01.11.2025
*/

public class BeerSongApp {
    public static void main(String[] args) {
        BeerSong song = new BeerSong(99); 
        song.sing();
    }
}
